server = {
    "NUM_CORES" : 8,
}